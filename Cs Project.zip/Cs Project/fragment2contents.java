package com.example.furkan.furkanfur;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

/**
 * Created by Furkan on 7/7/2017.
 */

public class fragment2contents extends Fragment {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    Button submit,button;
    RadioButton btn,btn2,btn3,btn4,btn7,btn6,btn8;
    String url = "http://139.179.135.151/images13.php";
    String url2 = "http://139.179.135.151/images14.php";
    String url4 = "http://139.179.135.151/images16.php";
    String url5 = "http://139.179.135.151/images17.php";
    String url6 = "http://139.179.135.151/images18.php";
    String url8 = "http://139.179.135.151/images20.php";
    String url9 = "http://139.179.135.151/images21.php";
    String url10 = "http://139.179.135.151/images15.php";
    String url11 = "http://139.179.135.151/images23.php";
    String url12 = "http://139.179.135.151/images19.php";
    String url131 = "http://139.179.135.151/images131.php";

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment2_main, container, false);
        btn = (RadioButton) rootView.findViewById(R.id.radioButton9);
        btn2 = (RadioButton) rootView.findViewById(R.id.radioButton10);
        btn3 = (RadioButton) rootView.findViewById(R.id.radioButton11);
        btn4 = (RadioButton) rootView.findViewById(R.id.radioButton12);
        btn6 = (RadioButton) rootView.findViewById(R.id.radioButton13);
        btn7 = (RadioButton) rootView.findViewById(R.id.radioButton14);
        btn8 = (RadioButton) rootView.findViewById(R.id.radioButton15);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.recyle);
        button = (Button) rootView.findViewById(R.id.button11);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
            }
        });
        submit = (Button) rootView.findViewById(R.id.button);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btn.isChecked() &&  btn3.isChecked() && btn6.isChecked())
                {
                    create(url);
                }
                else if(btn.isChecked() &&  btn3.isChecked() && btn7.isChecked())
                {
                    create(url2);
                }
                else if(btn.isChecked() &&  btn3.isChecked() && btn8.isChecked())
                {
                    Toast.makeText(getContext(),"No product found",Toast.LENGTH_SHORT).show();

                }
                else if(btn2.isChecked() &&  btn3.isChecked() && btn6.isChecked())
                {
                    create(url5);
                }

                else if(btn2.isChecked() &&  btn3.isChecked() && btn7.isChecked())
                {
                    create(url4);
                }

                else if(btn2.isChecked() &&  btn3.isChecked() && btn8.isChecked())
                {
                    create(url6);
                }
                else if(btn.isChecked() &&  btn4.isChecked() && btn6.isChecked())
                {
                    create(url);
                }
                else if(btn.isChecked() &&  btn4.isChecked() && btn7.isChecked())
                {
                    create(url2);
                }
                else if(btn.isChecked() &&  btn4.isChecked() && btn8.isChecked())
                {
                    Toast.makeText(getContext(),"No product found",Toast.LENGTH_SHORT).show();

                }
                else if(btn2.isChecked() &&  btn4.isChecked() && btn6.isChecked())
                {
                    Toast.makeText(getContext(),"No product found",Toast.LENGTH_SHORT).show();
                }
                else if(btn2.isChecked() &&  btn4.isChecked() && btn7.isChecked())
                {
                    create(url12);
                }
                else if(btn2.isChecked() &&  btn4.isChecked() && btn8.isChecked())
                {
                    create(url8);
                }
            }
        });

        return rootView;
    }
    public void create(String str)
    {
        final Adapter adapter = new Adapter(getContext());
        adapter.setUrl(str);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        adapter.bridge();
    }
    public void refresh()
    {
        if(btn.isChecked())
            btn.setChecked(false);
        if(btn2.isChecked())
            btn2.setChecked(false);
        if(btn3.isChecked())
            btn3.setChecked(false);
        if(btn4.isChecked())
            btn4.setChecked(false);
        if(btn6.isChecked())
            btn6.setChecked(false);
        if(btn7.isChecked())
            btn7.setChecked(false);
        if(btn8.isChecked())
            btn8.setChecked(false);
    }
}
