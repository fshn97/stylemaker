package com.example.furkan.furkanfur;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Handler;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.R.attr.data;

public class MainActivity extends AppCompatActivity {
    DrawerLayout dl;
    Toolbar tb;
    ActionBarDrawerToggle togg;
    FragmentTransaction transaction;
    NavigationView nv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.menulayout);

        tb = (Toolbar) findViewById(R.id.toolbar);
        tb.setTitle("Style Maker  ");
        dl = (DrawerLayout) findViewById(R.id.menulayout);
        togg = new ActionBarDrawerToggle(this,dl,tb,R.string.menu_open,R.string.menu_close);
        setSupportActionBar(tb);
        dl.setDrawerListener(togg);

        transaction = getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.mainframelayout,new MainMenuFragment());
        transaction.commit();

        nv = (NavigationView) findViewById(R.id.navigation_view);
        nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.action_add:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.commit();
                        Intent i = new Intent(MainActivity.this,AddCombMain.class);
                        startActivity(i);
                        tb.removeAllViews();
                        dl.closeDrawers();
                        break;
                    case R.id.action_old:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.mainframelayout,new OldCombinationsFragment());
                        transaction.commit();
                        tb.removeAllViews();
                        getSupportActionBar().setTitle("Old Combinations ");
                        tb.setMinimumWidth(5000);
                        dl.closeDrawers();
                        break;
                    case R.id.action_settings:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.mainframelayout,new SettingsFragment());
                        transaction.commit();
                        tb.removeAllViews();
                        getSupportActionBar().setTitle("Settings ");
                        tb.setMinimumWidth(5000);
                        dl.closeDrawers();
                        break;
                    case R.id.action_account:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.mainframelayout,new AccountFragment());
                        transaction.commit();
                        tb.removeAllViews();
                        getSupportActionBar().setTitle("Account Details  ");
                        tb.setMinimumWidth(5000);
                        dl.closeDrawers();
                        break;

                    case R.id.action_help:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.mainframelayout,new HelpFragment());
                        transaction.commit();
                        tb.removeAllViews();
                        getSupportActionBar().setTitle("Help  ");
                        tb.setMinimumWidth(5000);
                        dl.closeDrawers();
                        break;
                    case R.id.action_logout:
                        transaction = getSupportFragmentManager().beginTransaction();
                        Intent intent = new Intent(MainActivity.this,Login.class);
                        startActivity(intent);
                        transaction.commit();
                        tb.removeAllViews();
                        dl.closeDrawers();
                        break;
                }
                return true;
            }
        });


    }


}
