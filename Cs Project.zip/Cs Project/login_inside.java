package com.example.furkan.furkanfur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.afollestad.ason.Ason;
import com.afollestad.ason.AsonArray;
import com.afollestad.bridge.Bridge;
import com.afollestad.bridge.BridgeException;
import com.afollestad.bridge.Callback;
import com.afollestad.bridge.Form;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by Berke on 7/12/2017.
 */

public class login_inside extends AppCompatActivity{

    String reg_url = "http://139.179.135.151/login.php";
    EditText text,text2;
    String str, str2;
    boolean boo;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_inside_layout);
        text = (EditText) findViewById(R.id.editText2);
        text2 = (EditText) findViewById(R.id.editText5);
        str = text.getText().toString();
        str2 = text2.getText().toString();

        boo = false;
        Button btn = (Button) findViewById(R.id.button8);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Form form = new Form()
                        .add("name", str)
                        .add("password", str2);
                Bridge.post(reg_url)
                        .body(form)
                        .request(new Callback() {
                            @Override
                            public void response(@NotNull com.afollestad.bridge.Request request, @Nullable com.afollestad.bridge.Response response, @Nullable BridgeException e) {
                                if (e != null) {
                                    // See the 'Error Handling' section for information on how to process BridgeExceptions
                                    int reason = e.reason();
                                } else {

                                    try {
                                        Toast.makeText(getApplicationContext(),"sss",Toast.LENGTH_SHORT).show();
                                        // Use the Response object
                                        String code = "";
                                        AsonArray dataArray = response.asAsonArray();
                                        for (Object item : dataArray) {
                                            Ason object = (Ason) item;
                                            code = object.getString("code");
                                            Log.e("api", code);
                                        }
                                        Log.e("api", code);
                                            if(code.equals("login_success")){
                                                Toast.makeText(getApplicationContext(),"Oturum açıldı",Toast.LENGTH_SHORT).show();
                                                Intent i = new Intent(login_inside.this,MainActivity.class);
                                                startActivity(i);
                                            } else if(code.equals("can not login")){
                                                Toast.makeText(getApplicationContext(),"Kullanıcı bulunamadı",Toast.LENGTH_SHORT).show();
                                            }

                                    } catch (Exception ex) {
                                        Log.e("api", ex.getMessage());
                                    } finally {
                                    }
                                }
                            }
                        });


            }
        });

    }
}


