package com.example.furkan.furkanfur;

import android.app.DownloadManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.ason.Ason;
import com.afollestad.ason.AsonArray;
import com.afollestad.bridge.Bridge;
import com.afollestad.bridge.BridgeException;
import com.afollestad.bridge.Callback;
import com.afollestad.bridge.Form;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;
import static com.example.furkan.furkanfur.R.id.image;
import static com.example.furkan.furkanfur.R.id.imageView;
import static com.example.furkan.furkanfur.R.id.imageView2;

/**
 * Created by Furkan on 7/22/2017.
 */

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<List_item> list;
    private Context context;
    public static String url2;

    public Adapter( Context context) {
        this.list = new ArrayList<>();
        this.context = context;
        url2 = "";
        bridge();
    }

    public void setUrl(String url)
    {
        url2 = url;
    }

    @Override
    public Adapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txtid;
        public TextView txtdesc;
        public ImageView imageView;
        public LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            txtid = (TextView) itemView.findViewById(R.id.salary);
            txtdesc = (TextView) itemView.findViewById(R.id.age);
            imageView = (ImageView) itemView.findViewById(R.id.ff);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.linear);

        }
    }

    public void bridge() {
        Bridge.get(url2)
                .request(new Callback() {
                    @Override
                    public void response(@NotNull com.afollestad.bridge.Request request, @Nullable com.afollestad.bridge.Response response, @Nullable BridgeException e) {
                        if (e != null) {
                            int reason = e.reason();
                        } else {

                            try {
                                // Use the Response object
                                AsonArray dataArray = response.asAsonArray();
                                list.clear();

                                for (Object item : dataArray) {
                                    List_item newItem;
                                    Ason object = (Ason) item;
                                    String code1 = object.getString("id");
                                    String code2 = object.getString("description");
                                    String code3 =object.getString("image");
                                    newItem = new List_item(code1,code2,code3);
                                    list.add(newItem);
                                }
                                notifyDataSetChanged();

                            } catch (Exception ex) {
                                Log.e("api", ex.getMessage());
                            } finally {
                            }
                        }
                    }

                });
    }
    @Override
    public void onBindViewHolder(final Adapter.ViewHolder holder, int position) {
       final List_item item = list.get(position);

        holder.txtid.setText(item.getDescription());
        holder.txtdesc.setText(item.getId());

        Picasso.with(context).load(item.getImage()).into(holder.imageView);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Form form = new Form()
                        .add("url",item.getImage());
                Bridge.post("http://192.168.1.37/fromuser.php").body(form)
                        .request(new Callback() {
                            @Override
                            public void response(@NotNull com.afollestad.bridge.Request request, @Nullable com.afollestad.bridge.Response response, @Nullable BridgeException e) {
                                if (e != null) {
                                    // See the 'Error Handling' section for information on how to process BridgeExceptions
                                    int reason = e.reason();
                                } else {
                                    try {
                                        // Use the Response object
                                        AsonArray dataArray = response.asAsonArray();

                                            for (Object item : dataArray) {
                                                Ason object = (Ason) item;
                                                String code3 = object.getString("url");
                                        }
                                    } catch (Exception ex) {
                                        Log.e("api", ex.getMessage());
                                    } finally {
                                    }
                                }
                            }
                        });
                    Toast.makeText(context,"You have clicked", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
