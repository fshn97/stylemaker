package com.example.furkan.furkanfur;


import android.content.Context;
import android.graphics.Matrix;
import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import it.sephiroth.android.library.imagezoom.ImageViewTouchBase;


/**
 * A simple {@link Fragment} subclass.
 */
public class HelpFragment extends Fragment {

    ImageView view;
    Matrix matrix = new Matrix();
    Float scale = 1f;
    ScaleGestureDetector Sgd;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView = inflater.inflate(R.layout.fragment_help, container, false);
        Sgd = new ScaleGestureDetector(getContext(),new ScaleListener());
        view =  rootView.findViewById(R.id.menuhelp);
        final Animation zoomAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.layout);
        view.startAnimation(zoomAnimation);
        container.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                Sgd.onTouchEvent(motionEvent);
                return true;
            }
        });
        return rootView;
    }
    public class ScaleListener implements ScaleGestureDetector.OnScaleGestureListener
    {
        float onScaleBegin = 0;
        float onScaleEnd = 0;
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scale = scale * detector.getScaleFactor();
            view.setScaleX(scale);
            view.setScaleY(scale);
            return true;
        }

        @Override
        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            onScaleBegin = scale;
            return false;
        }

        @Override
        public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
            onScaleEnd = scale;
        }

    }

}
