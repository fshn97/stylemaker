package com.example.furkan.furkanfur;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

/**
 * Created by Furkan on 7/12/2017.
 */

public class Login extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        String uriPath2 = "android.resource://com.example.furkan.furkanfur/"+R.raw.movie;

        getWindow().setFormat(PixelFormat.UNKNOWN);
        VideoView mVideoView2 = (VideoView)findViewById(R.id.videoView1);

        Uri uri2 = Uri.parse(uriPath2);
        mVideoView2.setVideoURI(uri2);

        mVideoView2.requestFocus();
        mVideoView2.start();

        init();

    }
    public Button b;
    public Button b2;
    public void init()
    {
        b = (Button) findViewById(R.id.button7);
        b2 = (Button) findViewById(R.id.button10);
        b.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                Intent i = new Intent(Login.this,login_inside.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2 = new Intent(Login.this,login_signup.class);
                startActivity(i2);
            }
        });
    }
}
