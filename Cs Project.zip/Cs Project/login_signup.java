package com.example.furkan.furkanfur;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.afollestad.ason.Ason;
import com.afollestad.ason.AsonArray;
import com.afollestad.bridge.Bridge;
import com.afollestad.bridge.BridgeException;
import com.afollestad.bridge.Callback;
import com.afollestad.bridge.Form;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static java.security.AccessController.getContext;

/**
 * Created by Furkan on 7/15/2017.
 */

public class login_signup extends AppCompatActivity {

    EditText name0, pass0, conf0;
    Button btn;
    String name2, pass2, conf2;
    AlertDialog.Builder builder;
    String reg_url = "http://139.179.135.151/register.php";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_signup);

        name0 = (EditText) findViewById(R.id.editText0);
        pass0 = (EditText) findViewById(R.id.editText18);
        conf0 = (EditText) findViewById(R.id.editText17);
        btn = (Button) findViewById(R.id.button91);
        builder = new AlertDialog.Builder(login_signup.this);
        final Context ctn = getApplicationContext();
        btn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                name2 = name0.getText().toString().trim();
                pass2 = pass0.getText().toString().trim();
                conf2 = conf0.getText().toString().trim();
                if (name2.equals("") || pass2.equals("") || conf2.equals("")) {
                    builder.setTitle("Warning");
                    builder.setMessage("Please fill all of the sections");
                    displayAlert("input_error");
                }
                else if(!pass2.equals(conf2))
                {
                    builder.setTitle("Warning");
                    builder.setMessage("Password and Confirm Password does not match");
                    displayAlert("input_error");
                }
                else {
                    Form form = new Form()
                            .add("isim", name2)
                            .add("sifre", pass2);

                    Bridge.post(reg_url).body(form)
                            .request(new Callback() {
                                @Override
                                public void response(@NotNull com.afollestad.bridge.Request request, @Nullable com.afollestad.bridge.Response response, @Nullable BridgeException e) {
                                    if (e != null) {
                                        // See the 'Error Handling' section for information on how to process BridgeExceptions
                                        int reason = e.reason();
                                    } else {

                                        try {
                                            // Use the Response object
                                            AsonArray dataArray = response.asAsonArray();
                                            for (Object item : dataArray) {
                                                Ason object = (Ason) item;
                                                String code = object.getString("isim");
                                            }
                                        } catch (Exception ex) {
                                            Log.e("api", ex.getMessage());
                                        } finally {
                                        }
                                    }
                                }
                            });
                    Toast.makeText(getApplicationContext(),"You have successfully registered",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(login_signup.this,MainActivity.class);
                    startActivity(i);
                }
            }


        });

    }
    public void displayAlert(final String code) {
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (code.equals("input_error")) {
                    pass0.setText("");
                    name0.setText("");
                    conf0.setText("");
                }

            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}