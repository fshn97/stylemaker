package com.example.furkan.furkanfur;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;


/**
 * A simple {@link Fragment} subclass.
 */
public class OldCombinationsFragment extends Fragment {


    Button btn;
    ImageView v1;
    ImageUrl u = new ImageUrl();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_old_combinations, container, false);

        v1 = rootView.findViewById(R.id.sm);
        Toast.makeText(getContext(),u.getStr(),Toast.LENGTH_SHORT).show();
        btn = (Button) rootView.findViewById(R.id.button3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/*");
                String imagePath = Environment.getExternalStorageDirectory()
                        + "/20170727_103129.jpg";
                File imageFileToShare = new File(imagePath);
                Uri uri = Uri.fromFile(imageFileToShare);
                share.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(share, ""));
            }
        });




        return rootView;
    }

}
