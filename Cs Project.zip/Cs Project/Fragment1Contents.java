package com.example.furkan.furkanfur;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import com.afollestad.ason.Ason;
import com.afollestad.ason.AsonArray;
import com.afollestad.bridge.Bridge;
import com.afollestad.bridge.BridgeException;
import com.afollestad.bridge.Callback;
import com.afollestad.bridge.Form;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Furkan on 7/7/2017.
 */

public class Fragment1Contents extends Fragment
{
    private RecyclerView recyclerView;
    Button submit,button;
    RadioButton btn,btn2,btn3,btn4,btn7,btn6,btn8;
    String url = "http://139.179.135.151/images.php";
    String url2 = "http://139.179.135.151/images2.php";
    String url3 = "http://139.179.135.151/images3.php";
    String url4 = "http://139.179.135.151/images4.php";
    String url5 = "http://139.179.135.151/images5.php";
    String url6 = "http://139.179.135.151/images6.php";
    String url7 = "http://139.179.135.151/images7.php";
    String url8 = "http://139.179.135.151/images8.php";
    String url9 = "http://139.179.135.151/images9.php";
    String url10 = "http://139.179.135.151/images10.php";
    String url11 = "http://139.179.135.151/images11.php";
    String url12 = "http://139.179.135.151/images12.php";


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.fragment_main, container, false);

            btn = (RadioButton) rootView.findViewById(R.id.radioButton);
            btn2 = (RadioButton) rootView.findViewById(R.id.radioButton2);
            btn3 = (RadioButton) rootView.findViewById(R.id.radioButton3);
            btn4 = (RadioButton) rootView.findViewById(R.id.radioButton4);
            btn6 = (RadioButton) rootView.findViewById(R.id.radioButton6);
            btn7 = (RadioButton) rootView.findViewById(R.id.radioButton7);
            btn8 = (RadioButton) rootView.findViewById(R.id.radioButton8);
            recyclerView = (RecyclerView) rootView.findViewById(R.id.recyle);
            button = (Button) rootView.findViewById(R.id.button4);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    refresh();
                }
            });
            submit = (Button) rootView.findViewById(R.id.button);
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(btn.isChecked() &&  btn3.isChecked() && btn6.isChecked())
                    {
                        create(url);
                    }
                    else if(btn.isChecked() &&  btn3.isChecked() && btn7.isChecked())
                    {
                        create(url2);
                    }
                    else if(btn.isChecked() &&  btn3.isChecked() && btn8.isChecked())
                    {
                        create(url3);
                    }
                    else if(btn2.isChecked() &&  btn3.isChecked() && btn6.isChecked())
                    {
                        create(url4);
                    }
                    else if(btn2.isChecked() &&  btn3.isChecked() && btn7.isChecked())
                    {
                        create(url5);
                    }
                    else if(btn2.isChecked() &&  btn3.isChecked() && btn8.isChecked())
                    {
                        create(url6);
                    }
                    else if(btn.isChecked() &&  btn4.isChecked() && btn6.isChecked())
                    {
                        create(url7);
                    }
                    else if(btn.isChecked() &&  btn4.isChecked() && btn7.isChecked())
                    {
                        create(url8);
                    }
                    else if(btn.isChecked() &&  btn4.isChecked() && btn8.isChecked())
                    {
                        create(url9);
                    }
                    else if(btn2.isChecked() &&  btn4.isChecked() && btn6.isChecked())
                    {
                        create(url10);
                    }
                    else if(btn2.isChecked() &&  btn4.isChecked() && btn7.isChecked())
                    {
                        create(url11);
                    }
                    else if(btn2.isChecked() &&  btn4.isChecked() && btn8.isChecked())
                    {
                        create(url12);
                    }
                }
            });

        return rootView;
    }
    public void create(String str)
    {
        final Adapter adapter = new Adapter(getContext());
        adapter.setUrl(str);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        adapter.bridge();
    }
    public void refresh()
    {
        if(btn.isChecked())
            btn.setChecked(false);
        if(btn2.isChecked())
            btn2.setChecked(false);
        if(btn3.isChecked())
            btn3.setChecked(false);
        if(btn4.isChecked())
            btn4.setChecked(false);
        if(btn6.isChecked())
            btn6.setChecked(false);
        if(btn7.isChecked())
            btn7.setChecked(false);
        if(btn8.isChecked())
            btn8.setChecked(false);
    }
}