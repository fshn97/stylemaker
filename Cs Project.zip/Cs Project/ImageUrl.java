package com.example.furkan.furkanfur;

import android.content.Context;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import static com.example.furkan.furkanfur.R.id.imageView;

/**
 * Created by Furkan on 7/31/2017.
 */

public class ImageUrl {
    String str;

    public ImageUrl()
    {
        str = "";
    }
    public String getStr()
    {
        return str;
    }
    public void setStr(final String str2)
    {
        str = str2;
    }
}
